int innerlib(void) { return 0; }
