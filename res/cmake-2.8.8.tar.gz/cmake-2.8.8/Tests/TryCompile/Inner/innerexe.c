extern int innerlib(void);
int main() { return innerlib(); }
