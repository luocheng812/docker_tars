#include <qapplication.h>

class Foo : public QApplication
{
  Q_OBJECT
public:
  Foo();
};
