#include <stdio.h>

int main()
{
  printf("example1\n");
  return 0;
}
