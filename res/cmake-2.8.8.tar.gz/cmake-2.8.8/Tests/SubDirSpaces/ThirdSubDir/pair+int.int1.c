#include <stdio.h>

void pair_stuff()
{
  printf("Placeholder for a strange file in subdirectory\n");
}
