#include <stdio.h>

void secondone()
{
  printf("Hello again\n");
}
