#include <stdio.h>

void secondone();
void pair_stuff();
void vcl_stuff();

int main()
{
  printf("Hello from subdirectory\n");
  secondone();
  pair_stuff();
  vcl_stuff();
  return 0;
}
