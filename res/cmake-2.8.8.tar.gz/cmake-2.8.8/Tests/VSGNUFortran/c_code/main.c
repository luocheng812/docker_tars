#include <HelloWorldFCMangle.h> // created by FortranCInterface
extern void FC_hello(void);
int main()
{
 FC_hello();
 return 0;
}
