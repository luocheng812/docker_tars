
#include "lib2.h"
#include "lib1.h"

int add1_and_mult2(int num)
{
  int tmp = add1(num);
  return tmp * 2;
}
