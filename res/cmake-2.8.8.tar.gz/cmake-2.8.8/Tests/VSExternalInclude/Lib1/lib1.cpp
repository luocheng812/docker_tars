
#include "lib1.h"

int add1(int num)
{
  return num + 1;
}
