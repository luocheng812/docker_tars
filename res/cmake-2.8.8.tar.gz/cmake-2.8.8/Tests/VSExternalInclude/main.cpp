
#include "lib2.h"

int main(int argc, char** argv)
{
  int num = add1_and_mult2(4);

  return 0;
}
